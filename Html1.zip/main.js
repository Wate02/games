console.log('Hello World!');

function eytiapp2() {
  location.href = 'https://wate02.github.io/Mario64webgl/';
}

function sub() {
    location.href = 'https://wate02.github.io/Idk2/html5-games/games/subway-surfers-unity/';
}

function emu() {
    location.href = 'https://wate02.github.io/EmulatorJS//';
}


function imgtoclipboard() {
    location.href = 'https://wate02.github.io/Imgtoclipboard/';
}

function ctrtt() {
    location.href = 'https://wate02.github.io/Idk2/html5-games/games/ctr-TimeTravel/';
}


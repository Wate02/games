console.log('Hello World!');
function eytiapp2() {
  location.href = 'https://wate02.github.io/Mario64webgl/';
}

function eytiapp() {
    location.href = 'https://wate02.github.io/Mario64webgl/';
}

function emu() {
    location.href = 'https://wate02.github.io/EmulatorJS//';
}


function imgtoclipboard() {
    location.href = 'https://wate02.github.io/Imgtoclipboard/';
}

